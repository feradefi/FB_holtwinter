<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Produksi Mangga</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            background-color: #fffaf0; /* Cream color */
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #2c3e50; /* Dark navy blue for the title */
            font-style: italic;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #2c3e50; /* Dark navy blue for the title */
            
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #2c3e50; /* Dark navy blue */
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        button {
            padding: 8px 12px;
            background-color: #2c3e50; /* Dark navy blue */
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #34495e; /* Slightly lighter navy */
        }

        /* Styling for both buttons above */
        .button-container {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .forecast-button button, .add-button a {
            background-color: #2c3e50; /* Navy color */
            padding: 10px 18px; /* Smaller button size */
            font-size: 18px; /* Smaller font size */
            border-radius: 4px;
            font-weight: bold;s
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        
        .forecast-button button:hover, .add-button a:hover {
            background-color:rgb(102, 166, 230); /* Darker navy color on hover */
        }

        .add-button a {
            background-color:rgb(0, 225, 255);
            text-decoration: none;
            color: black;
        }

        /* Styling the warning button for 'Hapus' */
        .delete-button {
            background-color: red;
        }

        .delete-button:hover {
            background-color: #c0392b; /* Darker red */
        }
    </style>
</head>
<body>
    <div class="container">
    <header>
    <h1>Perhitungan Forecasting <br> Menggunakan Metode Holt-Winters</h1>
</header>
        <h2>Data Produksi Mangga</h2>

        <!-- Container for the buttons -->
        <div class="button-container">
            <!-- Ramal Button -->
            <div class="forecast-button">
                <form action="holtwinters.php" method="get">
                    <button type="submit">Ramal</button>
                </form>
            </div>
            <!-- Tambah Button -->
            <div class="add-button">
                <a href="tambah.php">Tambah Data</a>
            </div>
        </div>

        <hr>

        <!-- Tabel Data -->
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Tahun</th>
                    <th>Bulan</th>
                    <th>Produksi Mangga</th>
                    <th>Periode</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include 'connect.php';
                $query = "SELECT * FROM holtwinter_mangga";
                $result = mysqli_query($conn, $query);
                $no = 1;

                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>
                            <td>{$no}</td>
                            <td>{$row['tahun']}</td>
                            <td>{$row['bulan']}</td>
                            <td>{$row['produksi']}</td>
                            <td>{$row['periode']}</td>
                            <td>
                                <form action='edit.php' method='get' style='display:inline;'>
                                    <input type='hidden' name='id' value='{$row['id']}'>
                                    <button type='submit'>Edit</button>
                                </form>
                                <form action='hapus.php' method='post' style='display:inline;'>
                                    <input type='hidden' name='id' value='{$row['id']}'>
                                    <button type='submit' class='delete-button'>Hapus</button>
                                </form>
                            </td>
                        </tr>";
                        $no++;
                    }
                } else {
                    echo "<tr><td colspan='6'>Tidak ada data</td></tr>";
                }

                mysqli_close($conn);
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
