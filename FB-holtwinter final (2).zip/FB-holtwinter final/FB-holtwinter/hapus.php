<?php
include 'connect.php';

$id = $_POST['id']; // Retrieve the ID passed from the form

// Prepared statement to prevent SQL injection
$query = "DELETE FROM holtwinter_mangga WHERE id = ?";
$stmt = mysqli_prepare($conn, $query);

// Bind the ID parameter to the query
mysqli_stmt_bind_param($stmt, "i", $id);

// Execute the query
if (mysqli_stmt_execute($stmt)) {
    // Redirect to dashboard.php after successful deletion
    header("Location: dashboard.php");
} else {
    // Display an error message if the query fails
    echo "Error: " . mysqli_error($conn);
}

mysqli_stmt_close($stmt);
mysqli_close($conn);
?>
