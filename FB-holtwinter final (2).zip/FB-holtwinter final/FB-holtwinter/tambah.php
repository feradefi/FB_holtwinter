<?php
// Include the database connection
include 'connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $tahun = $_POST['tahun'];
    $bulan = $_POST['bulan'];
    $produksi = $_POST['produksi'];
    $periode = $_POST['periode'];

    // Insert data into the database
    $query = "INSERT INTO holtwinter_mangga (tahun, bulan, produksi, periode) 
              VALUES ('$tahun', '$bulan', '$produksi', '$periode')";

    if (mysqli_query($conn, $query)) {
        // Redirect to the main page after successful insertion
        header("Location: dashboard.php");
        exit();
    } else {
        // Handle error if insertion fails
        echo "Error: " . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Produksi Mangga</title>
    <style>
        /* Include the same styles as your previous page, or customize as needed */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin: 10px 0 5px;
        }

        input[type="text"], input[type="number"], input[type="submit"], select {
            width: 100%;
            padding: 8px;
            margin: 8px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #2c3e50; /* Dark navy blue */
            color: white;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #34495e; /* Slightly lighter navy */
        }

        .button-container {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .back-link {
            text-align: center;
            margin-top: 20px;
        }

        .back-link a {
            text-decoration: none;
            color: #4CAF50;
        }

        /* Shared button styles for both "Tambah Data" and "Kembali ke Dashboard" */
        .button {
            padding: 10px 20px;
            background-color: #2c3e50; /* Dark navy blue */
            color: white;
            border-radius: 4px;
            text-align: center;
            text-decoration: none;
        }

        .button:hover {
            background-color: #34495e; /* Slightly lighter navy */
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Tambah Data Produksi Mangga</h1>

        <div class="button-container">
            <!-- Kembali ke Dashboard Button -->
            <a href="dashboard.php" class="button">Kembali ke Dashboard</a>
        </div>

        <form action="tambah.php" method="post">
            <label for="tahun">Tahun</label>
            <input type="number" name="tahun" id="tahun" required>

            <label for="bulan">Bulan</label>
            <input type="text" name="bulan" id="bulan" required>

            <label for="produksi">Produksi Mangga</label>
            <input type="number" name="produksi" id="produksi" required>

            <label for="periode">Periode</label>
            <input type="number" name="periode" id="periode" required>

            <!-- "Tambah Data" Button -->
            <input type="submit" value="Tambah Data" class="button">
        </form>
    </div>
</body>
</html>
