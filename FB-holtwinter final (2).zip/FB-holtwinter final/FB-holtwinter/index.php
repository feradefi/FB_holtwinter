<?php
// Redirect to login.php
header("Location: login.php");
exit();
?>
