<?php
include 'connect.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Query to fetch data for the given ID
    $query = "SELECT * FROM holtwinter_mangga WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $data = mysqli_fetch_assoc($result);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Retrieve updated data from the form
        $produksi = $_POST['produksi'];
        $periode = $_POST['periode'];
        $tahun = $_POST['tahun'];
        $bulan = $_POST['bulan'];

        // Query to update data in the database
        $updateQuery = "UPDATE holtwinter_mangga SET produksi = ?, periode = ?, tahun = ?, bulan = ? WHERE id = ?";
        $updateStmt = mysqli_prepare($conn, $updateQuery);
        mysqli_stmt_bind_param($updateStmt, "ssssi", $produksi, $periode, $tahun, $bulan, $id);

        if (mysqli_stmt_execute($updateStmt)) {
            header('Location: dashboard.php');
            exit;
        } else {
            echo "Error updating record: " . mysqli_error($conn);
        }
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produksi Mangga</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-size: 1.1rem;
            margin: 8px 0;
        }

        input[type="text"], input[type="number"], button {
            padding: 10px;
            margin: 8px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
        }

        button {
            background-color: #2c3e#2c3;
            color: white;
            cursor: pointer;
            border: none;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #34495e;
        }

        .back-link {
            text-align: center;
            margin-top: 20px;
        }

        .back-link a {
            text-decoration: none;
            color: #4CAF50;
            font-weight: bold;
        }

        .error-message {
            color: red;
            font-size: 1.1rem;
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Edit Data Produksi Mangga</h1>

        <?php if (isset($data)) : ?>
        <form action="" method="post">
            <label for="tahun">Tahun:</label>
            <input type="number" id="tahun" name="tahun" value="<?= htmlspecialchars($data['tahun']) ?>" required>

            <label for="bulan">Bulan:</label>
            <input type="text" id="bulan" name="bulan" value="<?= htmlspecialchars($data['bulan']) ?>" required>

            <label for="produksi">Produksi Mangga:</label>
            <input type="number" id="produksi" name="produksi" value="<?= htmlspecialchars($data['produksi']) ?>" required>

            <label for="periode">Periode:</label>
            <input type="text" id="periode" name="periode" value="<?= htmlspecialchars($data['periode']) ?>" required>

            <button type="submit">Update</button>
        </form>
        <?php else: ?>
            <p class="error-message">Data tidak ditemukan.</p>
        <?php endif; ?>
        
        <div class="back-link">
            <a href="dashboard.php">Kembali ke Dashboard</a>
        </div>
    </div>
</body>
</html>
