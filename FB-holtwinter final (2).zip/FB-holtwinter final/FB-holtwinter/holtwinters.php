 <?php
include 'connect.php';

function calculateHoltWinters($rows, $alpha, $beta, $gamma) {
    $n = count($rows);

     // Inisialisasi Level, Trend, dan Seasonal Index untuk periode 1-12
    // Level (A1) dihitung sebagai rata-rata produksi 12 bulan pertama
    $level = array_sum(array_column(array_slice($rows, 0, 12), 'produksi')) / 12;
    
    // Trend (T1) dihitung berdasarkan perubahan rata-rata antara bulan pertama dan bulan terakhir
    $trend = (array_sum(array_column(array_slice($rows, 12, 12), 'produksi')) - array_sum(array_column(array_slice($rows, 0, 12), 'produksi'))) / (12 * 12);
    
    // Inisialisasi Seasonal Index (St) untuk 12 bulan pertama
    $season = array_fill(0, 12, 0);

    // Urutkan data berdasarkan ID
    usort($rows, function($a, $b) {
        return $a['id'] <=> $b['id'];
    });

    foreach (array_slice($rows, 0, 12) as $i => $row) {
        $season[$i] = $row['produksi'] - $level;
    }
    $results = [];
    
    // Loop untuk perhitungan Holt-Winters
    foreach ($rows as $i => $row) {
        $tahun = $row['tahun'];
        $bulan = $row['bulan'];
        $produksi = $row['produksi'];
        $periode = $row['periode'];

       // Menyimpan nilai sebelumnya untuk At, Tt, dan St
       $last_level = $level; // At periode sebelumnya
       $last_trend = $trend; // Tt periode sebelumnya
       $last_season = $season[$i % 12]; // St dari periode musiman terkait

       if ($i > 11) { // Untuk periode 13 dan seterusnya
           // Menghitung Level (At) untuk periode berikutnya
           $season_index = ($i - 12) % 12;
           $level = $alpha * ($produksi - $season[$season_index]) + (1 - $alpha) * ($last_level + $last_trend);

           // Menghitung Trend (Tt)
           $trend = $beta * ($level - $last_level) + (1 - $beta) * $last_trend;

           // Menghitung Seasonal Index (St)
           $season[$i % 12] = $gamma * ($produksi - $level) + (1 - $gamma) * $last_season;
       }

       // Forecast dihitung setelah periode 12
       $forecast_value = ($i > 11) ? $last_level + $last_trend + $last_season : null;

       // Error
       $error = ($forecast_value !== null) ? $forecast_value - $produksi  : null;

       // Metrik tambahan
       $At_minus_Ft = ($error !== null) ? $produksi - $forecast_value : null;
       $At_minus_Ft_squared = ($error !== null) ? pow($At_minus_Ft, 2) : null;
       $abs_error_percentage = ($error !== null) ? abs($error / $produksi) : null;
       
       // Menghitung Yl+t - Yt (Yl_plus_T_Yt)
       $Yl_plus_T_Yt = '-'; // Nilai default adalah '-'
       if ($periode <= 12) {
           $periode_l = $periode + 12;
           $produksi_periode = 0;
           $produksi_periode_l = 0;

           foreach ($rows as $row_check) {
               if ($row_check['periode'] == $periode) {
                   $produksi_periode = $row_check['produksi'];
               }
               if ($row_check['periode'] == $periode_l) {
                   $produksi_periode_l = $row_check['produksi'];
               }
           }
           if ($produksi_periode != 0 && $produksi_periode_l != 0) {
               $Yl_plus_T_Yt = $produksi_periode_l - $produksi_periode;
           }
       }

       // Menyimpan hasil perhitungan untuk setiap periode
       $results[] = [
           'tahun' => $tahun,
           'bulan' => $bulan,
           'produksi' => $produksi,
           'periode' => $periode,
           'Yl_plus_T_Yt' => $Yl_plus_T_Yt,
           'level' => $level,
           'trend' => $trend,
           'season' => $season[$i % 12],
           'forecast' => $forecast_value,
           'error' => $error,
           'At_minus_Ft' => $At_minus_Ft,
           'At_minus_Ft_squared' => $At_minus_Ft_squared,
           'abs_error_percentage' => $abs_error_percentage
       ];
   }

   // Menghitung MSE dan MAPE
   $mse = array_sum(array_column($results, 'At_minus_Ft_squared')) / count($results);
   $mape = array_sum(array_column($results, 'abs_error_percentage')) / count($results);

    // Peramalan untuk 12 bulan berikutnya
    $future_forecast = [];
    $periode_lanjutan = [];
    $last_level = $level; // At periode terakhir (periode 132)
    $last_trend = $trend; // Tt periode terakhir (periode 132)

    for ($i = 1; $i <= 12; $i++) {
        // Seasonal index dari 12 periode sebelumnya
        $season_index = ($i - 1) % 12; // Gunakan seasonal index berulang
        $future_forecast[] = $last_level + $last_trend + $season[$season_index];
        $periode_lanjutan[] = 132 + $i; // Periode lanjutan
    }

   return [
       'results' => $results,
       'mse' => $mse,
       'mape' => $mape,
       'future_forecast' => $future_forecast,
       'periode_lanjutan' => $periode_lanjutan
   ];
}

$query = "SELECT * FROM holtwinter_mangga ORDER BY tahun, bulan";
$result = $conn->query($query);

if (!$result) {
   die("Error: " . $conn->error);
}

$rows = $result->fetch_all(MYSQLI_ASSOC);

if (!$rows || empty($rows)) {
   $results = [
       'results' => [],
       'mse' => 0,
       'mape' => 0,
       'future_forecast' => [],
       'periode_lanjutan' => []
   ];
} else {
   $alpha = isset($_POST['alpha']) ? max(0, min(1, floatval($_POST['alpha']))) : 0.01;
   $beta = isset($_POST['beta']) ? max(0, min(1, floatval($_POST['beta']))) : 0.02;
   $gamma = isset($_POST['gamma']) ? max(0, min(1, floatval($_POST['gamma']))) : 0.05;
   $results = calculateHoltWinters($rows, $alpha, $beta, $gamma);
}

usort($results['results'], function($a, $b) {
   if ($a['tahun'] == $b['tahun']) {
       return $a['bulan'] - $b['bulan'];
   }
   return $a['tahun'] - $b['tahun'];
});
?>

    
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Holt-Winters Forecasting</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        header {
            padding: 15px;
            text-align: center;
        }
        h1 {
            font-size: 24px;
        }
        h2{
            text-align: center;
        }
        h4 {
            text-align: center;
            font-size: 20px;
        }
        form {
            background-color: #fff;
            padding: 20px;
            margin: 20px;
            border-radius: 5px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        input[type="number"], button {
            padding: 8px;
            margin: 5px 0;
            border-radius: 4px;
            border: 1px solid #ddd;
        }
        button {
            background-color: #2c3e50;
            color: white;
            cursor: pointer;
        }
        button:hover {
            background-color: #0033aa;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table th, table td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
        }
        table th {
            background-color: #2c3e50;
        }
        ul {
            list-style-type: none;
            padding: 0;
        }
        ul li {
            padding: 5px 0;
        }

        /* Gaya dasar untuk tabel */
table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
    font-size: 16px;AC
    text-align: left;
}

/* Gaya untuk header tabel */
th {
    background-color: #2c3e50; /* Warna hijau untuk header */
    padding: 10px;
    color: white;
}

/* Gaya untuk baris tabel */
tr:nth-child(even) {
    background-color: #f2f2f2; /* Warna abu-abu muda untuk baris genap */
}

tr:nth-child(odd) {
    background-color: #ffffff; /* Warna putih untuk baris ganjil */
}

td {
    padding: 8px;
    border: 1px solid #ddd;
}

/* Warna untuk kolom tertentu */
td:nth-child(3) {
    background-color: #ffebcc; /* Kolom Produksi Mangga dengan warna kuning muda */
}

td:nth-child(9) {
    background-color: #d1ecf1; /* Kolom Forecast dengan warna biru muda */
}

/* Pemberian warna untuk nilai negatif di kolom error */
td.negative {
    color: red;
    font-weight: bold;
}

td.positive {
    color: green;
    font-weight: bold;
}

    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

</head>
<body>

<header>
    <h1>Perhitungan Forecasting Menggunakan Metode Holt-Winters</h1>
</header>

<form action="holtwinters.php" method="post">
    <label for="alpha">Alpha:</label>
    <input type="number" name="alpha" id="alpha" step="0.01" value="<?= $alpha ?>" required>
    <label for="beta">Beta:</label>
    <input type="number" name="beta" id="beta" step="0.01" value="<?= $beta ?>" required>
    <label for="gamma">Gamma:</label>
    <input type="number" name="gamma" id="gamma" step="0.01" value="<?= $gamma ?>" required>
    <button type="submit">Hitung Ulang</button>
</form>

<h2>Hasil Perhitungan</h2>
<table>
    <thead>
        <tr>
            <th>Tahun</th>
            <th>Bulan</th>
            <th>Produksi Mangga</th>
            <th>Periode</th>
            <th>Yl+t - Yt</th>
            <th>At</th>
            <th>Tt</th>
            <th>St</th>
            <th>Forecast</th>
            <th>MSE</th>
            <th>MAPE</th>
            <th>Error</th>
        </tr>
    </thead>
    <tbody>
    <?php 
    // Loop through each result to calculate MSE and MAPE
    foreach ($results['results'] as $index => $result) {
        // Menentukan apakah At dan Tt ditampilkan
        $show_level_trend = ($index >= 11); // Tampilkan Level dan Trend hanya untuk periode >= 12
      
        // Calculate MSE: (Produksi - Forecast)^2
        if ($index >= 12) {  // Period 13 corresponds to index 12 (0-based index)
            $mse = pow($result['produksi'] - $result['forecast'], 2);

            // Calculate MAPE: ABS(Produksi - Forecast) / Produksi (without multiplying by 100)
            $mape = abs($result['produksi'] - $result['forecast']) / $result['produksi'];
        } else {
            $mse = null;
            $mape = null;
        }
    ?>
        <tr>
            <td><?= $result['tahun'] ?></td>
            <td><?= number_format($result['bulan'], 0, '.', '') ?></td> <!-- Replace $row with $result -->
            <td><?= number_format($result['produksi'], 0, '.', '') ?></td> <!-- Replace $row with $result -->
            <td><?= $result['periode'] ?></td> <!-- Replace $row with $result -->
            <td><?= $result['Yl_plus_T_Yt'] ?></td> <!-- Replace $row with $result -->
            <td><?= $show_level_trend ? number_format($result['level'], 2, '.', '') : '-' ?></td>
            <td><?= $show_level_trend ? number_format($result['trend'], 2, '.', '') : '-' ?></td>
             <td><?= number_format($result['season'], 2) ?></td> <!-- Replace $row with $result -->
            <td><?= isset($result['forecast']) ? number_format($result['forecast'], 2) : '-' ?></td>
            <td><?= $mse !== null ? number_format($mse, 2) : '-' ?></td>
            <td><?= $mape !== null ? number_format($mape, 4) : '-' ?></td>
            <td><?= isset($result['error']) ? number_format($result['error'], 2) : '-' ?></td>
        </tr>
    <?php } ?>
</tbody>

</table>
<h2>Peramalan 12 Bulan Berikutnya:</h2>
<table>
    <thead>
        <tr>
            <th>Bulan</th>
            <th>Lanjutan Periode</th>
            <th>Forecast Value</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        // Iterating through the future forecast and periode_lanjutan arrays
        foreach ($results['periode_lanjutan'] as $key => $periode): 
            $month = $key + 1; // Month number starts from 1
        ?>
            <tr>
                <td><?= $month ?></td>
                <td><?= $periode ?></td>
                <td><?= number_format($results['future_forecast'][$key], 2, '.', '') ?></td>
                </tr>
        <?php endforeach; ?>
    </tbody>
</table>


<h4>MSE: <?= number_format($results['mse'], 4) ?></h4>
<h4>MAPE: <?= number_format($results['mape'] * 100, 2) ?>%</h4>

<form method="post">
<h2>Grafik Produksi dan Forecasting</h2>
<div class="chart-container">
    <canvas id="forecastChart" width="500" height="250"></canvas>
</div>

<script>
// Data produksi aktual dari PHP (2013-2023)
const dataProduksi = <?= json_encode(array_column($results['results'], 'produksi')) ?>;

// Data forecast dari hasil perhitungan (2014-2024)
const forecastData = <?= json_encode($results['future_forecast']) ?>;

// Pastikan data tidak null atau kosong
console.log("Data Produksi: ", dataProduksi);
console.log("Forecast Data: ", forecastData);

// Label tahun gabungan (2013 - 2024)
const allYears = Array.from({ length: 12 }, (_, i) => 2013 + i);

// Data produksi hanya sampai tahun 2023, tanpa data 2024
const combinedDataProduksi = dataProduksi; // Data produksi hanya sampai tahun 2023

// Data forecast mulai dari tahun 2014-2024
const combinedForecastData = forecastData; // Forecast mulai dari tahun 2014-2024

console.log("Tahun:", allYears);
console.log("Data Produksi (Dibatasi 2023):", combinedDataProduksi);
console.log("Data Forecast:", combinedForecastData);

// Membuat grafik menggunakan Chart.js
const ctx = document.getElementById('forecastChart').getContext('2d');

new Chart(ctx, {
    type: 'line',
    data: {
        labels: allYears, // Tahun 2013-2024
        datasets: [
            {
                label: 'Produksi Mangga',
                data: combinedDataProduksi.concat([null]), // Garis produksi berhenti di 2023, ditambah null untuk tahun 2024
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 2,
                fill: false,
                spanGaps: false // Garis produksi berhenti di 2023
            },
            {
                label: 'Forecast Mangga',
                data: [null].concat(combinedForecastData), // Forecast mulai dari 2014-2024
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 2,
                fill: false,
                borderDash: [5, 5] // Garis putus-putus untuk forecast
            }
        ]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                display: true,
                position: 'top',
            }
        },
        scales: {
            x: {
                title: {
                    display: true,
                    text: 'Tahun'
                }
            },
            y: {
                title: {
                    display: true,
                    text: 'Produksi & Forecast Mangga'
                }
            }
        }
    }
});
</script>
</form>

</body>
</html>