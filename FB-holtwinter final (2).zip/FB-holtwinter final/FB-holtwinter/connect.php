<?php
// Menyimpan informasi koneksi database
$host = 'localhost';    // Host database
$db   = 'holtwinter_db';  // Nama database
$user = 'root';         // Username database
$pass = '';             // Password database (sesuaikan dengan pengaturan Anda)

// Membuat koneksi ke database
$conn = new mysqli($host, $user, $pass, $db);

// Cek koneksi, jika gagal tampilkan pesan error
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Menetapkan charset untuk memastikan karakter dalam database ditangani dengan benar
$conn->set_charset("utf8mb4");

?>
