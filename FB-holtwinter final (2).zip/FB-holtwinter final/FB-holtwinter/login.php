<?php
session_start();

// Include the database connection
include('connect.php');

// Process the login
if (isset($_POST['login'])) {
    $pengguna = $_POST['pengguna'];
    $kata_sandi = $_POST['kata_sandi'];

    // Query to check the user
    $sql = "SELECT * FROM `user` WHERE `pengguna` = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $pengguna);
    $stmt->execute();
    $result = $stmt->get_result();

    // If user found
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Verify the password
        if ($kata_sandi == $row['kata_sandi']) {
            // Set session and redirect to the dashboard
            $_SESSION['pengguna'] = $pengguna;
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Incorrect password!";
        }
    } else {
        $error = "User not found!";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        /* Reset some default styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(45deg, #2C3E50, #D5D8DC); /* Navy and cream gradient */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #fff;
        }

        .container {
            background-color: #fff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 400px;
            color: #333;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 24px;
            color: #333;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-size: 14px;
        }

        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 16px;
        }

        button {
            width: 100%;
            padding: 14px;
            background-color: #2C3E50; /* Navy color */
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #34495E; /* Darker navy */
        }

        .error-message {
            color: red;
            text-align: center;
            margin-bottom: 15px;
        }

        p {
            text-align: center;
            margin-top: 15px;
        }

        a {
            text-decoration: none;
            color: #2C3E50; /* Navy color */
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Login</h2>

        <?php if (isset($error)) { echo "<p class='error-message'>$error</p>"; } ?>

        <form method="POST" action="login.php">
            <div>
                <label for="pengguna">Username:</label>
                <input type="text" id="pengguna" name="pengguna" required>
            </div>
            <div>
                <label for="kata_sandi">Password:</label>
                <input type="password" id="kata_sandi" name="kata_sandi" required>
            </div>
            <button type="submit" name="login">Login</button>
        </form>

    </div>

</body>
</html>
